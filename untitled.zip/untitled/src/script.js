let timerInterval;
let seconds = 0;
let isRunning = false;

function updateTimerDisplay() {
  let mins = Math.floor(seconds / 60);
  let secs = seconds % 60;
  document.getElementById(
    "timerDisplay"
  ).textContent = `${mins
    .toString()
    .padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

document.getElementById("startBtn").addEventListener("click", () => {
  if (!isRunning) {
    isRunning = true;
    timerInterval = setInterval(() => {
      seconds++;
      updateTimerDisplay();
    }, 1000);
  }
});

document.getElementById("stopBtn").addEventListener("click", () => {
  if (isRunning) {
    clearInterval(timerInterval);
    isRunning = false;

    // حساب عدد الكلمات
    let text = document.getElementById("textInput").value.trim();
    let words = text.split(/\s+/).filter((w) => w.length > 0).length;

    // الأخطاء
    let mistakes =
      parseInt(document.getElementById("mistakesInput").value) || 0;

    // عدد الكلمات الصحيحة
    let correctWords = Math.max(words - mistakes, 0);

    // سرعة القراءة
    let minutes = seconds / 60;
    let wpm = minutes > 0 ? Math.round(correctWords / minutes) : 0;

    document.getElementById(
      "result"
    ).innerHTML = `عدد الكلمات الصحيحة في الدقيقة: <strong>${wpm}</strong>`;
  }
});
